import{m as r}from"./entry.7d0f722a.js";function t(e,u){return r()._useHead(e,u)}export{t as u};
