
import { defuFn } from '/home/bhakti/Projects/nuxt-project/lovinadolphintoursnew/node_modules/defu/dist/defu.mjs'

const inlineConfig = {}



export default defuFn(inlineConfig)
