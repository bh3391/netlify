globalThis._importMeta_={url:import.meta.url,env:process.env};import 'file:///home/bhakti/Projects/nuxt-project/lovinadolphintoursnew/node_modules/node-fetch-native/dist/polyfill.mjs';
export { l as localFetch } from './chunks/nitro/nitro-prerenderer.mjs';
import 'file:///home/bhakti/Projects/nuxt-project/lovinadolphintoursnew/node_modules/h3/dist/index.mjs';
import 'file:///home/bhakti/Projects/nuxt-project/lovinadolphintoursnew/node_modules/ofetch/dist/node.mjs';
import 'file:///home/bhakti/Projects/nuxt-project/lovinadolphintoursnew/node_modules/destr/dist/index.mjs';
import 'file:///home/bhakti/Projects/nuxt-project/lovinadolphintoursnew/node_modules/unenv/runtime/fetch/index.mjs';
import 'file:///home/bhakti/Projects/nuxt-project/lovinadolphintoursnew/node_modules/hookable/dist/index.mjs';
import 'file:///home/bhakti/Projects/nuxt-project/lovinadolphintoursnew/node_modules/scule/dist/index.mjs';
import 'file:///home/bhakti/Projects/nuxt-project/lovinadolphintoursnew/node_modules/ohash/dist/index.mjs';
import 'file:///home/bhakti/Projects/nuxt-project/lovinadolphintoursnew/node_modules/ufo/dist/index.mjs';
import 'file:///home/bhakti/Projects/nuxt-project/lovinadolphintoursnew/node_modules/unstorage/dist/index.mjs';
import 'file:///home/bhakti/Projects/nuxt-project/lovinadolphintoursnew/node_modules/unstorage/drivers/fs.mjs';
import 'file:///home/bhakti/Projects/nuxt-project/lovinadolphintoursnew/node_modules/defu/dist/defu.mjs';
import 'file:///home/bhakti/Projects/nuxt-project/lovinadolphintoursnew/node_modules/radix3/dist/index.mjs';
import 'node:url';
import 'file:///home/bhakti/Projects/nuxt-project/lovinadolphintoursnew/node_modules/ipx/dist/index.mjs';
//# sourceMappingURL=index.mjs.map
