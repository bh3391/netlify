const defaults = {"component":"OgImageBasic","width":1200,"height":630};
const fonts = ["Inter:400","Inter:700"];
const satoriOptions = {};
const assetDirs = ["/home/bhakti/Projects/nuxt-project/lovinadolphintoursnew/public","/home/bhakti/Projects/nuxt-project/lovinadolphintoursnew/node_modules/nuxt-og-image/dist/runtime/public-assets"];

export { assetDirs as a, defaults as d, fonts as f, satoriOptions as s };
//# sourceMappingURL=config.mjs.map
