import { defineEventHandler, getQuery, getHeaders, createError } from 'file:///home/bhakti/Projects/nuxt-project/lovinadolphintoursnew/node_modules/h3/dist/index.mjs';
import { d as defaults } from '../rollup/config.mjs';
import { g as getRouteRules } from '../nitro/nitro-prerenderer.mjs';
import 'file:///home/bhakti/Projects/nuxt-project/lovinadolphintoursnew/node_modules/node-fetch-native/dist/polyfill.mjs';
import 'file:///home/bhakti/Projects/nuxt-project/lovinadolphintoursnew/node_modules/ofetch/dist/node.mjs';
import 'file:///home/bhakti/Projects/nuxt-project/lovinadolphintoursnew/node_modules/destr/dist/index.mjs';
import 'file:///home/bhakti/Projects/nuxt-project/lovinadolphintoursnew/node_modules/unenv/runtime/fetch/index.mjs';
import 'file:///home/bhakti/Projects/nuxt-project/lovinadolphintoursnew/node_modules/hookable/dist/index.mjs';
import 'file:///home/bhakti/Projects/nuxt-project/lovinadolphintoursnew/node_modules/scule/dist/index.mjs';
import 'file:///home/bhakti/Projects/nuxt-project/lovinadolphintoursnew/node_modules/ohash/dist/index.mjs';
import 'file:///home/bhakti/Projects/nuxt-project/lovinadolphintoursnew/node_modules/ufo/dist/index.mjs';
import 'file:///home/bhakti/Projects/nuxt-project/lovinadolphintoursnew/node_modules/unstorage/dist/index.mjs';
import 'file:///home/bhakti/Projects/nuxt-project/lovinadolphintoursnew/node_modules/unstorage/drivers/fs.mjs';
import 'file:///home/bhakti/Projects/nuxt-project/lovinadolphintoursnew/node_modules/defu/dist/defu.mjs';
import 'file:///home/bhakti/Projects/nuxt-project/lovinadolphintoursnew/node_modules/radix3/dist/index.mjs';
import 'node:url';
import 'file:///home/bhakti/Projects/nuxt-project/lovinadolphintoursnew/node_modules/ipx/dist/index.mjs';

function extractOgImageOptions(html) {
  const options = html.match(/<script id="nuxt-og-image-options" type="application\/json">(.+?)<\/script>/)?.[1];
  return options ? JSON.parse(options) : false;
}
const inferOgImageOptions = (html) => {
  const options = {};
  const description = html.match(/<meta property="og:description" content="(.*?)">/)?.[1];
  if (description)
    options.description = description;
  else
    options.description = html.match(/<meta name="description" content="(.*?)">/)?.[1];
  return options;
};
const options = defineEventHandler(async (e) => {
  const query = getQuery(e);
  const path = query.path || "/";
  const fetchOptions = {
    headers: getHeaders(e)
  } ;
  const html = await globalThis.$fetch(path, {
    ...fetchOptions
  });
  const extractedPayload = extractOgImageOptions(html);
  if (!extractedPayload) {
    throw createError({
      statusCode: 500,
      statusMessage: `The path ${path} is missing the og-image payload.`
    });
  }
  e.node.req.url = path;
  e.context._nitro.routeRules = void 0;
  const routeRules = getRouteRules(e)?.ogImage;
  e.node.req.url = e.path;
  if (routeRules === false)
    return false;
  return {
    path,
    ...defaults,
    // use inferred data
    ...inferOgImageOptions(html),
    // use route rules
    ...routeRules || {},
    // use provided data
    ...extractedPayload,
    // use query data
    ...query
  };
});

export { options as default, extractOgImageOptions, inferOgImageOptions };
//# sourceMappingURL=options.mjs.map
