<template>
     <div class="hero min-h-screen" style="background-image: url(../6.webp);">
        <div class="hero-overlay bg-opacity-60"></div>
        <div class="hero-content text-center text-white">
            <div class="max-w-md">
                <h1 class="mb-5 text-3xl font-bold">Welcome to Our Website</h1>
                <p class="mb-5">Thank you for visiting our website.Do you want to find out about  dolphins, snorkeling or fishing at Lovina Beach?<br>
                Right here you can order directly with Lovina Ocean Tours with affordable Price.Before you Order, Please Check Our </p>
                <a href="https://www.tripadvisor.com/Attraction_Review-g1599559-d21042518-Reviews-Lovina_Ocean_Dolphin_Tour-Lovina_Beach_Buleleng_District_Buleleng_Regency_Bali.html" alt="Tripadvisor Link"><div class="btn bg-green-600 hover:bg-green-300 ">
                    <nuxt-img alt="tripadvisor" loading="lazy" width="100px" height="50px" class="w-10 m-2" src="/tripadvisor.svg"/></div></a>
            </div>
        </div>
    </div>
</template>