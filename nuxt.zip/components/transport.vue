<template>
    <section class="text-gray-600 body-font">
        <div class="container px-5 py-24 mx-auto flex flex-wrap flex-col">
            <nuxt-img loading="lazy" width="720" height="600" class=" block mx-auto mb-10 object-cover object-center rounded" alt="transport"
                src="/transport.webp"/>
            <div class="flex flex-col text-center w-full">
                <h1 class="text-xl  title-font mb-4 font-bold text-4xl text-gray-900">Transport Service</h1>
                <p class="lg:w-2/3 mx-auto leading-relaxed text-gray-800 text-xl">We Also Pr ovide Pick Up and Drop Off Service for you
                    who stay arround Bali Area with Affordable price<br>

                    1.Transport Service From Kuta Fixed Price IDR 600 K <br>
                    2.Transport Service From Tuban Fixed Price IDR 600 K <br>
                    3.Transport Service From Canggu Fixed Price IDR 600 K <br>
                    4.Transport Service From Seminyak Fixed Price IDR 600 K <br>
                    5.Transport Service From Ubud Fixed Price IDR 600 K</p>
            </div>
        </div>
    </section>
</template>