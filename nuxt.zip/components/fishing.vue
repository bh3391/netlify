<template>
    <section class="text-gray-900 hover:bg-gradient-to-tl from-green-100 via-sky-300 to-sky-200 transition duration-50 bg-gradient-to-br body-font overflow-hidden">
        <div class="container px-5 py-24 mx-auto">
            <div class="lg:w-4/5 mx-auto flex flex-wrap">
                <Fishingcarousel class="lg:w-1/2" />
                <div class="lg:w-1/2 w-full lg:pl-10 lg:py-6 mt-6 lg:mt-0">
                    <h2 class="text-md title-font text-black tracking-widest">Lovina Dolphin Tours.com</h2>
                    <h1 class="text-gray-900 text-3xl title-font font-medium mb-1">Fishing At Sunset</h1>
                    <hr>
                    <br>
                    <p class="leading-relaxed text-lg text-justify">Join us for a thrilling fishing tour at Lovina and cast
                        your line in search of the catch of a lifetime. With our knowledgeable guides and top-quality
                        equipment, you'll have the opportunity to reel in a variety of exotic fish species. Whether you're a
                        seasoned angler or a first-timer, this tour is sure to be an unforgettable experience. Book now and
                        let the adventure begin!</p><br>
                    <div>
                        <div class="overflow-x-auto ">
                            <table class="table w-full text-purple-900 ">
                                <!-- head -->
                                <thead>
                                    <tr>

                                        <th>Package</th>
                                        <th>Adult</th>
                                        <th>Children(4-7)</th>

                                    </tr>
                                </thead>
                                <tbody>
                                    <!-- row 1 -->
                                    <tr>

                                        <td>Sharing Package</td>
                                        <td>150k/person</td>
                                        <td> 50k/person</td>

                                    </tr>
                                    <!-- row 2 -->
                                    <tr>

                                        <td>Private Boat Package</td>
                                        <td>200k/person</td>
                                        <td>100k/person</td>

                                    </tr>

                                </tbody>
                            </table>
                        </div>
                    </div>
                    <br>

                    <div class="flex">
                        <span class="title-font font-medium text-sm text-gray-900">**Price is Included Experienced Boat &
                            Captain Boat.
                            Lifejacket / Buoy.
                            Hammock
                            Free Visit Lovina Marine Park / feeding fish.<br>
                            Fishing duration 3 hours</span>


                    </div>
                    <Booknow />
                    <br>
                    <hr>

                </div>
            </div>
    </div>
</section></template>