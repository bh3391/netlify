<template>
    <a href="https://wa.link/ovli9r" >
    <div class="hover:scale-110 transition flex flex-center justify-center"><nuxt-img loading="lazy" width="160" height="90" src="/booknow1.svg" alt="book button"/></div></a>

</template>