<template>
    <div class="flex  flex-col md:flex-row gap-3  p-2 mx-auto">
        <Swimprice />
        <Dolphinprice/>
        <Snorklingprice/>
        
    </div><br>
    <Fishing /><br>
</template>