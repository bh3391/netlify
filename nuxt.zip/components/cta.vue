<template>
    <section class="bg-white dark:bg-gray-900">
        <div class="container flex flex-col items-center px-4 py-12 mx-auto text-center">
            <h2
                class="max-w-2xl mx-auto text-2xl font-semibold tracking-tight text-gray-800 xl:text-3xl dark:text-white">
                Bring your Adventure to the <span class="text-blue-500">next level.</span>
            </h2>

            <p class="max-w-4xl mt-6 text-center text-gray-500 dark:text-gray-300">
                "Join us on a breathtaking adventure to witness the grace and beauty of dolphins in their natural
                habitat! Book your dolphin watching tour now and experience the thrill of watching these amazing
                creatures swim and play. Don't miss this once in a lifetime opportunity! Call us today to reserve your
                spot."
            </p>

            <div class="inline-flex w-full items-center justify-center mt-6 sm:w-auto">
    <Booknow />
            </div>
        </div>
    </section>
</template>