<template>
    <section class="text-gray-900 rounded-lg lg:w-1/3 hover:bg-gradient-to-tl transition duration-50 bg-gradient-to-br from-green-100 via-sky-200 to-sky-300 body-font overflow-hidden">
        <div class="container px-5 py-10 mx-auto">
            <div class=" mx-auto flex flex-col">
                <Snorklingcarousel />
                <div class="w-full ">
                    <h2 class="text-md title-font text-black tracking-widest">Lovina Dolphin Tours.com</h2>
                    <h1 class="text-gray-900 text-3xl title-font font-medium mb-1">Snorkling At Lovina</h1>
                    <hr>
                    <br>
                    <p class="leading-relaxed text-lg text-justify">Dive into the crystal-clear waters of Lovina and
                        discover the vibrant marine life on our snorkeling adventure. With our experienced guides, you'll
                        explore the stunning coral reefs and swim with a variety of colorful fish. Don't miss this chance to
                        experience the beauty of the underwater world. Book your snorkeling tour at Lovina today!</p><br>
                    <div>
                        <div class="overflow-x-auto ">
                            <table class="table w-full text-purple-900 opacity-80 font-bold">
                                <!-- head -->
                                <thead>
                                    <tr>

                                        <th>Package</th>
                                        <th>Adult</th>
                                        <th>Children(4-7)</th>

                                    </tr>
                                </thead>
                                <tbody>
                                    <!-- row 1 -->
                                    <tr>

                                        <td>Sharing Package</td>
                                        <td>100k/person</td>
                                        <td> 50k/person</td>

                                    </tr>
                                    <!-- row 2 -->
                                    <tr>

                                        <td>Private Boat Package</td>
                                        <td>150k/person</td>
                                        <td>100k/person</td>

                                    </tr>

                                </tbody>
                            </table>
                        </div>
                    </div>
                    <br>

                    <div class="flex">
                        <span class="title-font font-medium text-sm text-gray-900">**Price is Included Experienced Boat &
                            Captain Boat.
                            Lifejacket / Buoy.
                            Hammock
                            Free Visit Lovina Marine Park / feeding fish.<br>
                            Snorkling duration hours</span>


                    </div>
                    <Booknow />
                    <br>
                </div>
            </div>
        </div>
</section></template>