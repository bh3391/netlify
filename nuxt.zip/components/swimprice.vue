<template>
    <section class="text-gray-900 rounded-lg lg:w-1/3 hover:bg-gradient-to-tl  transition duration-50  from-green-100 via-sky-200 to-sky-300 body bg-gradient-to-br f-font overflow-hidden">
            <div class="container px-5 py-10 before:mx-auto">
                <div class=" mx-auto flex flex-col">
                    <Swimcarousel class="w-full"/>
                    <div class="w-full ">
                        <h2 class="text-md title-font text-black tracking-widest">Lovina dolphin Tours.com</h2>
                        <h1 class="text-gray-900 text-3xl title-font font-medium mb-1">Swimming With Dolphin</h1>
                        <hr>
                        <br>
                        <p class="leading-relaxed text-lg text-justify">Join us for an unforgettable experience and swim
                            with the playful
                            dolphins in their natural habitat. With our expert guides, you'll learn about these magnificent
                            creatures and have the opportunity to interact with them in their underwater world. Don't miss
                            this once in a lifetime opportunity, book your dolphin swim today!.</p><br>
                        <div>
                            <div class="overflow-x-auto ">
                                <table class="table w-full  text-purple-900 font-bold ">
                                    <!-- head -->
                                    <thead>
                                        <tr>

                                            <th>Package</th>
                                            <th>Adult</th>
                                            <th>Children(4-7)</th>

                                        </tr>
                                    </thead>
                                    <tbody>
                                        <!-- row 1 -->
                                        <tr>

                                            <td>Sharing Package</td>
                                            <td>150k/person</td>
                                            <td>100k/person</td>

                                        </tr>
                                        <!-- row 2 -->
                                        <tr>

                                            <td>Private Boat Package</td>
                                            <td>250k/person</td>
                                            <td>100k/person</td>

                                        </tr>

                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <br>

                        <div class="flex">
                            <span class="title-font font-medium text-sm text-gray-900">**Price is Included - Experienced
                                Boat & Captain Boat.
                                Lifejacket / Buoy.
                                Snorkeling Equipment
                                Free Visit Lovina Marine Park / feeding fish.<br>
                                Swim With Dolphin duration 3 hours</span>
                            

                        </div>
                        <Booknow/>
                        <br>
                    </div>
                </div>
            </div>
        </section>
</template>