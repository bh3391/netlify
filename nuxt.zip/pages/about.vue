<template>
    <div class="divider">Profile</div>
    <Profile/>
    <div class="divider">Our Advantages</div>
    <Advantage/>
</template>