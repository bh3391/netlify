<template>
    <Foto/>
</template>