<template>
    <Contact />
    <Map />
    </template>