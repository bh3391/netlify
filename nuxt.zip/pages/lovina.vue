<template>
    <lovina/>
    <Profile/>
    <Contact/>
</template>